﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex04.Menus.Interfaces
{
	public interface IDescribable
	{
		string Description
		{
			get;
		}
	}
}
